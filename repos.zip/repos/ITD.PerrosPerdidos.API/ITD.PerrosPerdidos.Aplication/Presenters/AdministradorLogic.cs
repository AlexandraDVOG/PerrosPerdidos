﻿using ITD.PerrosPerdidos.Domain.DTO.DATA.Atributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ITD.PerrosPerdidos.Aplication.Presenters
{
    public class AdministradorLogic
    {
        public List<AdministradorAtributes> GetAdministrador();
        List<AdministradorAtributes> administradorAtributes = new List<AdministradorAtributes>();
        
        {


        }
    }
}
