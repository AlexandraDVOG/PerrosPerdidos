﻿using ITD.PerrosPerdidos.Domain.DTO.DATA;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ITD.PerrosPerdidos.Domain.DTO
{
    public class MacotasPerdidas
    {
        public MascotasPerdidasData data { get; set; }
    }
}
