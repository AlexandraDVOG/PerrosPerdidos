﻿using ITD.PerrosPerdidos.Domain.DTO.DATA;
namespace ITD.PerrosPerdidos.Domain.DTO
{
    public class Administrador
    {
        public AdministradorData data { get; set; }


    }
}
