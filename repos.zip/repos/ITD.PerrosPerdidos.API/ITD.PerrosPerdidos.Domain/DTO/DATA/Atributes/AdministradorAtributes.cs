﻿
namespace ITD.PerrosPerdidos.Domain.DTO.DATA.Atributes
{
    public class AdministradorAtributes
    {
        public string usuario {  get; set; }
        public string telefono { get; set; }   
        public string contraseña { get; set; }

    }
}
