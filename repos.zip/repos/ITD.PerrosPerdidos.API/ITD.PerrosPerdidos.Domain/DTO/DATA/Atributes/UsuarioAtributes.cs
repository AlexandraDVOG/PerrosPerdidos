﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ITD.PerrosPerdidos.Domain.DTO.DATA.Atributes
{
    public class UsuarioAtributes
    {
        public string usuario { get; set; }
        public int? numero_celular { get; set; }
        public string contraseña { get; set; }
    }
}
