﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ITD.PerrosPerdidos.Domain.POCOS.Context
{
    public class MascotasPerdidasContext
    {
        public string raza { get; set; }
        public string color { get; set; }
        public string tamaño { get; set; }
        public string sexo { get; set; }
        public string celular { get; set; }
        public string imagen { get; set; }
    }
}
