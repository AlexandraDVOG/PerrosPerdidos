﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ITD.PerrosPerdidos.Domain.POCOS.Context
{
    public class PublicacionContext
    {
        public string Fecha_Publicacion { get; set; }
    }
}
