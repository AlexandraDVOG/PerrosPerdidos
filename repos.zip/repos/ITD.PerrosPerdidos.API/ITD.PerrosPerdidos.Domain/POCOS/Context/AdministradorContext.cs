﻿

namespace ITD.PerrosPerdidos.Domain.POCOS.Context
{
    public class AdministradorContext
    {
        public string usuario { get; set; }
        public string telefono { get; set; }
        public string contraseña { get; set; }
    }
}
